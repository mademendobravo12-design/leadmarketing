import ZAI from 'z-ai-web-dev-sdk';

export interface LeadData {
  fuenteOrigen: string;
  tiempoEnSitioMin: number;
  visitasTotales: number;
  diasUltimoContacto: number;
  cargo: string;
  sector: string;
}

export interface PredictionResult {
  probabilidadConversion: number;
  clasificacion: string;
  recomendacion: string;
  factoresInfluencia: {
    factor: string;
    peso: number;
    descripcion: string;
  }[];
}

export interface LeadStats {
  totalLeads: number;
  convertidos: number;
  tasaConversion: number;
  distribucionFuentes: { fuente: string; count: number; percentage: number }[];
}

class MLService {
  private zai: any = null;

  private async initializeAI() {
    if (!this.zai) {
      this.zai = await ZAI.create();
    }
    return this.zai;
  }

  async predecirConversion(leadData: LeadData): Promise<PredictionResult> {
    try {
      const zai = await this.initializeAI();

      // Calcular características base para el modelo
      const scoreTiempo = Math.min(leadData.tiempoEnSitioMin / 60, 1) * 100; // Normalizar a 0-100
      const scoreVisitas = Math.min(leadData.visitasTotales / 20, 1) * 100;
      const scoreRecencia = Math.max(0, 1 - leadData.diasUltimoContacto / 30) * 100;

      // Factores de fuente de origen
      const factoresFuente: { [key: string]: number } = {
        'Google Ads': 85,
        'Orgánico': 75,
        'LinkedIn': 70,
        'Referido': 90,
        'Facebook': 60
      };

      // Factores de cargo
      const factoresCargo: { [key: string]: number } = {
        'Gerente': 80,
        'Director': 85,
        'Analista': 65,
        'Becario': 45,
        'Coordinador': 60,
        'Supervisor': 70
      };

      // Factores de sector
      const factoresSector: { [key: string]: number } = {
        'Tecnología': 80,
        'Finanzas': 75,
        'Salud': 70,
        'Retail': 60,
        'Educación': 65,
        'Manufactura': 55
      };

      const scoreFuente = factoresFuente[leadData.fuenteOrigen] || 50;
      const scoreCargo = factoresCargo[leadData.cargo] || 50;
      const scoreSector = factoresSector[leadData.sector] || 50;

      // Calcular probabilidad ponderada
      const pesos = {
        tiempo: 0.25,
        visitas: 0.20,
        recencia: 0.20,
        fuente: 0.15,
        cargo: 0.10,
        sector: 0.10
      };

      let probabilidad = (
        scoreTiempo * pesos.tiempo +
        scoreVisitas * pesos.visitas +
        scoreRecencia * pesos.recencia +
        scoreFuente * pesos.fuente +
        scoreCargo * pesos.cargo +
        scoreSector * pesos.sector
      );

      // Ajuste con IA para mayor precisión
      const prompt = `
Como experto en marketing digital y machine learning, analiza este lead y ajusta la probabilidad de conversión:

Datos del lead:
- Fuente: ${leadData.fuenteOrigen}
- Tiempo en sitio: ${leadData.tiempoEnSitioMin} minutos
- Visitas totales: ${leadData.visitasTotales}
- Días desde último contacto: ${leadData.diasUltimoContacto}
- Cargo: ${leadData.cargo}
- Sector: ${leadData.sector}

Probabilidad calculada inicial: ${probabilidad.toFixed(1)}%

Considera patrones de comportamiento typical y ajusta la probabilidad final. Responde SOLO con un número entre 0 y 100 que represente el porcentaje de probabilidad de conversión.
      `;

      try {
        const completion = await zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: 'Eres un experto en análisis de leads de marketing digital con años de experiencia en machine learning aplicado a conversiones.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.3,
          max_tokens: 10
        });

        const aiAdjustment = parseFloat(completion.choices[0]?.message?.content || '0');
        if (!isNaN(aiAdjustment) && aiAdjustment > 0 && aiAdjustment <= 100) {
          probabilidad = (probabilidad * 0.7) + (aiAdjustment * 0.3); // 70% cálculo, 30% IA
        }
      } catch (error) {
        console.log('Error en ajuste IA, usando cálculo manual:', error);
      }

      probabilidad = Math.max(0, Math.min(100, probabilidad));

      // Determinar clasificación
      let clasificacion: string;
      let recomendacion: string;

      if (probabilidad >= 70) {
        clasificacion = 'Alta';
        recomendacion = 'Contactar inmediatamente - Lead prioritario con alta probabilidad de conversión';
      } else if (probabilidad >= 40) {
        clasificacion = 'Media';
        recomendacion = 'Contactar en las próximas 48 horas - Lead con potencial moderado';
      } else {
        clasificacion = 'Baja';
        recomendacion = 'Incluir en campaña de nutrición - Baja prioridad inmediata';
      }

      // Factores de influencia
      const factoresInfluencia = [
        {
          factor: 'Tiempo en Sitio',
          peso: scoreTiempo,
          descripcion: leadData.tiempoEnSitioMin > 30 ? 'Excelente engagement' : 
                      leadData.tiempoEnSitioMin > 15 ? 'Buen engagement' : 'Engagement bajo'
        },
        {
          factor: 'Visitas Totales',
          peso: scoreVisitas,
          descripcion: leadData.visitasTotales > 10 ? 'Lead muy interesado' :
                      leadData.visitasTotales > 5 ? 'Lead interesado' : 'Lead exploratorio'
        },
        {
          factor: 'Recencia',
          peso: scoreRecencia,
          descripcion: leadData.diasUltimoContacto <= 7 ? 'Muy reciente' :
                      leadData.diasUltimoContacto <= 14 ? 'Reciente' : 'Antiguo'
        },
        {
          factor: 'Fuente de Origen',
          peso: scoreFuente,
          descripcion: `Calidad de fuente: ${this.getCalidadFuente(leadData.fuenteOrigen)}`
        },
        {
          factor: 'Cargo',
          peso: scoreCargo,
          descripcion: `Nivel de decisión: ${this.getNivelDecision(leadData.cargo)}`
        },
        {
          factor: 'Sector',
          peso: scoreSector,
          descripcion: `Potencial del sector: ${this.getPotencialSector(leadData.sector)}`
        }
      ];

      return {
        probabilidadConversion: probabilidad / 100,
        clasificacion,
        recomendacion,
        factoresInfluencia
      };

    } catch (error) {
      console.error('Error en predicción:', error);
      // Retornar valores por defecto en caso de error
      return {
        probabilidadConversion: 0.5,
        clasificacion: 'Media',
        recomendacion: 'Requiere análisis manual',
        factoresInfluencia: []
      };
    }
  }

  private getCalidadFuente(fuente: string): string {
    const calidades: { [key: string]: string } = {
      'Google Ads': 'Alta',
      'Referido': 'Muy Alta',
      'Orgánico': 'Alta',
      'LinkedIn': 'Media-Alta',
      'Facebook': 'Media'
    };
    return calidades[fuente] || 'Media';
  }

  private getNivelDecision(cargo: string): string {
    const niveles: { [key: string]: string } = {
      'Director': 'Alto',
      'Gerente': 'Alto',
      'Supervisor': 'Medio',
      'Analista': 'Medio-Bajo',
      'Becario': 'Bajo',
      'Coordinador': 'Medio'
    };
    return niveles[cargo] || 'Medio';
  }

  private getPotencialSector(sector: string): string {
    const potenciales: { [key: string]: string } = {
      'Tecnología': 'Alto',
      'Finanzas': 'Alto',
      'Salud': 'Medio-Alto',
      'Educación': 'Medio',
      'Retail': 'Medio',
      'Manufactura': 'Medio-Bajo'
    };
    return potenciales[sector] || 'Medio';
  }

  async generarDatosEjemplo(): Promise<any[]> {
    const fuentes = ['Google Ads', 'Facebook', 'Orgánico', 'LinkedIn', 'Referido'];
    const cargos = ['Gerente', 'Analista', 'Becario', 'Director', 'Coordinador', 'Supervisor'];
    const sectores = ['Tecnología', 'Finanzas', 'Salud', 'Retail', 'Educación', 'Manufactura'];

    const datos = [];

    for (let i = 0; i < 300; i++) {
      const fuenteOrigen = fuentes[Math.floor(Math.random() * fuentes.length)];
      const tiempoEnSitioMin = Math.random() * 120 + 5; // 5-125 minutos
      const visitasTotales = Math.floor(Math.random() * 25) + 1; // 1-25 visitas
      const diasUltimoContacto = Math.floor(Math.random() * 30); // 0-29 días
      const cargo = cargos[Math.floor(Math.random() * cargos.length)];
      const sector = sectores[Math.floor(Math.random() * sectores.length)];

      // Calcular probabilidad de conversión basada en las características
      let probBase = 0.3; // Base 30%

      // Ajustes según características
      if (tiempoEnSitioMin > 30) probBase += 0.2;
      if (visitasTotales > 10) probBase += 0.2;
      if (diasUltimoContacto < 7) probBase += 0.15;
      if (fuenteOrigen === 'Referido' || fuenteOrigen === 'Google Ads') probBase += 0.1;
      if (cargo === 'Gerente' || cargo === 'Director') probBase += 0.1;
      if (sector === 'Tecnología' || sector === 'Finanzas') probBase += 0.05;

      probBase = Math.max(0, Math.min(1, probBase));
      const convertido = Math.random() < probBase;

      datos.push({
        id: `lead_${i + 1}`,
        fuenteOrigen,
        tiempoEnSitioMin: parseFloat(tiempoEnSitioMin.toFixed(2)),
        visitasTotales,
        diasUltimoContacto,
        cargo,
        sector,
        convertido,
        probabilidadConversion: probBase,
        clusterPrioridad: probBase > 0.7 ? 'Alta' : probBase > 0.4 ? 'Media' : 'Baja'
      });
    }

    return datos;
  }
}

export const mlService = new MLService();
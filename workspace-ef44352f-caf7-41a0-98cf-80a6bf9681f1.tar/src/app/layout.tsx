import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "LeadPredict AI - Sistema de Predicción de Leads",
  description: "Sistema inteligente de Machine Learning para predecir la conversión de leads de marketing. Optimiza tus campañas con IA y análisis predictivo.",
  keywords: ["LeadPredict AI", "Machine Learning", "Predicción de Leads", "Marketing Digital", "Conversión", "IA", "Next.js", "TypeScript"],
  authors: [{ name: "LeadPredict AI Team" }],
  icons: {
    icon: "/logo-leadpredict.png",
    shortcut: "/logo-leadpredict.png",
    apple: "/logo-leadpredict.png",
  },
  openGraph: {
    title: "LeadPredict AI - Predicción Inteligente de Leads",
    description: "Sistema de Machine Learning para optimizar la conversión de leads con análisis predictivo avanzado",
    url: "https://leadpredict-ai.com",
    siteName: "LeadPredict AI",
    type: "website",
    images: [
      {
        url: "/dashboard-preview.png",
        width: 1024,
        height: 1024,
        alt: "LeadPredict AI Dashboard",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "LeadPredict AI - Predicción de Leads",
    description: "Sistema inteligente de Machine Learning para marketing digital",
    images: ["/dashboard-preview.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-gray-50 text-gray-900`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}

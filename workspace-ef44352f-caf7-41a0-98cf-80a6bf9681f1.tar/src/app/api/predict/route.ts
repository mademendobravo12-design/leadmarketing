import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { mlService } from '@/lib/ml-service';

export async function GET() {
  try {
    // Obtener estadísticas generales
    const totalLeads = await db.lead.count();
    const convertidos = await db.lead.count({
      where: { convertido: true }
    });
    const tasaConversion = totalLeads > 0 ? (convertidos / totalLeads) * 100 : 0;

    // Distribución por fuente de origen
    const leadsPorFuente = await db.lead.groupBy({
      by: ['fuenteOrigen'],
      _count: {
        id: true
      }
    });

    const distribucionFuentes = leadsPorFuente.map(item => ({
      fuente: item.fuenteOrigen,
      count: item._count.id,
      percentage: totalLeads > 0 ? (item._count.id / totalLeads) * 100 : 0
    }));

    const stats = {
      totalLeads,
      convertidos,
      tasaConversion: parseFloat(tasaConversion.toFixed(2)),
      distribucionFuentes
    };

    return NextResponse.json(stats);
  } catch (error) {
    console.error('Error al obtener estadísticas:', error);
    return NextResponse.json(
      { error: 'Error al obtener estadísticas' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validar datos requeridos
    const { fuenteOrigen, tiempoEnSitioMin, visitasTotales, diasUltimoContacto, cargo, sector } = body;
    
    if (!fuenteOrigen || !tiempoEnSitioMin || !visitasTotales || !diasUltimoContacto || !cargo || !sector) {
      return NextResponse.json(
        { error: 'Faltan datos requeridos para la predicción' },
        { status: 400 }
      );
    }

    // Realizar predicción
    const prediction = await mlService.predecirConversion({
      fuenteOrigen,
      tiempoEnSitioMin: parseFloat(tiempoEnSitioMin),
      visitasTotales: parseInt(visitasTotales),
      diasUltimoContacto: parseInt(diasUltimoContacto),
      cargo,
      sector
    });

    // Guardar predicción en la base de datos
    await db.prediccion.create({
      data: {
        fuenteOrigen,
        tiempoEnSitioMin: parseFloat(tiempoEnSitioMin),
        visitasTotales: parseInt(visitasTotales),
        diasUltimoContacto: parseInt(diasUltimoContacto),
        cargo,
        sector,
        probabilidadConversion: prediction.probabilidadConversion,
        clasificacion: prediction.clasificacion,
        recomendacion: prediction.recomendacion,
        factoresInfluencia: JSON.stringify(prediction.factoresInfluencia)
      }
    });

    return NextResponse.json(prediction);
  } catch (error) {
    console.error('Error en predicción:', error);
    return NextResponse.json(
      { error: 'Error al procesar la predicción' },
      { status: 500 }
    );
  }
}
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { mlService } from '@/lib/ml-service';

export async function POST() {
  try {
    // Generar datos de ejemplo
    const datosEjemplo = await mlService.generarDatosEjemplo();

    // Insertar en la base de datos
    for (const lead of datosEjemplo) {
      await db.lead.create({
        data: {
          fuenteOrigen: lead.fuenteOrigen,
          tiempoEnSitioMin: lead.tiempoEnSitioMin,
          visitasTotales: lead.visitasTotales,
          diasUltimoContacto: lead.diasUltimoContacto,
          cargo: lead.cargo,
          sector: lead.sector,
          convertido: lead.convertido,
          probabilidadConversion: lead.probabilidadConversion,
          clusterPrioridad: lead.clusterPrioridad
        }
      });
    }

    return NextResponse.json({ 
      message: 'Datos de ejemplo generados exitosamente',
      totalLeads: datosEjemplo.length
    });
  } catch (error) {
    console.error('Error al generar datos de ejemplo:', error);
    return NextResponse.json(
      { error: 'Error al generar datos de ejemplo' },
      { status: 500 }
    );
  }
}
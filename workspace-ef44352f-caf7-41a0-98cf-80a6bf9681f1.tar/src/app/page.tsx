'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

interface LeadStats {
  totalLeads: number;
  convertidos: number;
  tasaConversion: number;
  distribucionFuentes: { fuente: string; count: number; percentage: number }[];
}

interface PredictionResult {
  probabilidadConversion: number;
  clasificacion: string;
  recomendacion: string;
  factoresInfluencia: {
    factor: string;
    peso: number;
    descripcion: string;
  }[];
}

const COLORS = ['#0056B3', '#28A745', '#FFC107', '#DC3545', '#6F42C1'];

export default function Home() {
  const [stats, setStats] = useState<LeadStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [showPredictionForm, setShowPredictionForm] = useState(false);
  const [predictionResult, setPredictionResult] = useState<PredictionResult | null>(null);
  const [formData, setFormData] = useState({
    fuenteOrigen: '',
    tiempoEnSitioMin: '',
    visitasTotales: '',
    diasUltimoContacto: '',
    cargo: '',
    sector: ''
  });

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/predict');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error al obtener estadísticas:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePrediction = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/api/predict', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();
      setPredictionResult(result);
      setShowPredictionForm(false);
      await fetchStats();
    } catch (error) {
      console.error('Error en predicción:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateSeedData = async () => {
    try {
      const response = await fetch('/api/seed-data', {
        method: 'POST',
      });
      const result = await response.json();
      alert(result.message);
      await fetchStats();
    } catch (error) {
      console.error('Error al generar datos:', error);
    }
  };

  if (loading && !stats) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-blue-600 rounded mr-3"></div>
                <span className="text-xl font-semibold text-gray-900">LeadPredict AI</span>
              </div>
            </div>
          </div>
        </header>
        <div className="flex items-center justify-center min-h-[600px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-lg text-gray-600">Cargando sistema...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Corporativo */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded mr-3"></div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">LeadPredict AI</h1>
                <p className="text-xs text-gray-500">Sistema Inteligente de Predicción de Leads</p>
              </div>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-gray-700 hover:text-blue-600 px-3 py-2 text-sm font-medium">Dashboard</a>
              <a href="#" className="text-gray-500 hover:text-blue-600 px-3 py-2 text-sm font-medium">Análisis</a>
              <a href="#" className="text-gray-500 hover:text-blue-600 px-3 py-2 text-sm font-medium">Reportes</a>
              <a href="#" className="text-gray-500 hover:text-blue-600 px-3 py-2 text-sm font-medium">Configuración</a>
            </nav>
            <Button onClick={generateSeedData} variant="outline" size="sm">
              Generar Datos
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg p-8 mb-8 text-white">
          <div className="max-w-3xl">
            <h2 className="text-3xl font-bold mb-4">Sistema de Predicción de Conversión de Leads</h2>
            <p className="text-blue-100 mb-6">
              Machine Learning aplicado al marketing digital para optimizar la conversión de prospectos y maximizar el ROI de tus campañas
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
                <div className="text-2xl font-bold">{stats?.totalLeads || 0}</div>
                <div className="text-sm text-blue-100">Total Leads</div>
              </div>
              <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
                <div className="text-2xl font-bold">{stats?.convertidos || 0}</div>
                <div className="text-sm text-blue-100">Convertidos</div>
              </div>
              <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
                <div className="text-2xl font-bold">{stats?.tasaConversion.toFixed(1) || 0}%</div>
                <div className="text-sm text-blue-100">Tasa Conversión</div>
              </div>
            </div>
          </div>
        </div>

        {/* Sección de Evaluación Principal - Prioridad #1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Formulario de Predicción */}
          <Card className="shadow-lg border-0">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
              <CardTitle className="text-xl font-semibold flex items-center">
                <div className="w-3 h-3 bg-white rounded-full mr-3"></div>
                Evaluar Nuevo Lead
              </CardTitle>
              <CardDescription className="text-blue-100">
                Analiza instantáneamente la probabilidad de conversión con nuestra IA
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              {!showPredictionForm ? (
                <div className="text-center py-8">
                  <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">¿Lista para analizar un lead?</h3>
                  <p className="text-gray-600 mb-6 max-w-sm mx-auto">
                    Ingresa los datos del prospecto y obtén una predicción precisa en segundos con nuestro algoritmo de Machine Learning
                  </p>
                  <Button 
                    onClick={() => setShowPredictionForm(true)}
                    className="bg-blue-600 hover:bg-blue-700 w-full h-12 text-lg font-semibold"
                    size="lg"
                  >
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    Comenzar Evaluación
                  </Button>
                </div>
              ) : (
                <form onSubmit={handlePrediction} className="space-y-6">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                    <div className="flex items-center">
                      <svg className="w-5 h-5 text-blue-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <p className="text-sm text-blue-800 font-medium">Completa todos los campos para obtener una predicción precisa</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="fuenteOrigen" className="text-sm font-semibold text-gray-700 mb-2 block">Fuente de Origen *</Label>
                      <Select onValueChange={(value) => handleInputChange('fuenteOrigen', value)} required>
                        <SelectTrigger className="h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                          <SelectValue placeholder="Seleccionar fuente" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Google Ads">🔍 Google Ads</SelectItem>
                          <SelectItem value="Facebook">📘 Facebook</SelectItem>
                          <SelectItem value="Orgánico">🌱 Orgánico</SelectItem>
                          <SelectItem value="LinkedIn">💼 LinkedIn</SelectItem>
                          <SelectItem value="Referido">👥 Referido</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="tiempoEnSitioMin" className="text-sm font-semibold text-gray-700 mb-2 block">Tiempo en Sitio (min) *</Label>
                      <Input
                        id="tiempoEnSitioMin"
                        type="number"
                        step="0.1"
                        min="0"
                        placeholder="45.5"
                        value={formData.tiempoEnSitioMin}
                        onChange={(e) => handleInputChange('tiempoEnSitioMin', e.target.value)}
                        className="h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="visitasTotales" className="text-sm font-semibold text-gray-700 mb-2 block">Visitas Totales *</Label>
                      <Input
                        id="visitasTotales"
                        type="number"
                        min="1"
                        placeholder="12"
                        value={formData.visitasTotales}
                        onChange={(e) => handleInputChange('visitasTotales', e.target.value)}
                        className="h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="diasUltimoContacto" className="text-sm font-semibold text-gray-700 mb-2 block">Días desde Último Contacto *</Label>
                      <Input
                        id="diasUltimoContacto"
                        type="number"
                        min="0"
                        placeholder="3"
                        value={formData.diasUltimoContacto}
                        onChange={(e) => handleInputChange('diasUltimoContacto', e.target.value)}
                        className="h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="cargo" className="text-sm font-semibold text-gray-700 mb-2 block">Cargo *</Label>
                      <Select onValueChange={(value) => handleInputChange('cargo', value)} required>
                        <SelectTrigger className="h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                          <SelectValue placeholder="Seleccionar cargo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Gerente">👔 Gerente</SelectItem>
                          <SelectItem value="Director">🎯 Director</SelectItem>
                          <SelectItem value="Analista">📊 Analista</SelectItem>
                          <SelectItem value="Becario">🎓 Becario</SelectItem>
                          <SelectItem value="Coordinador">⚙️ Coordinador</SelectItem>
                          <SelectItem value="Supervisor">👨‍💼 Supervisor</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="sector" className="text-sm font-semibold text-gray-700 mb-2 block">Sector *</Label>
                      <Select onValueChange={(value) => handleInputChange('sector', value)} required>
                        <SelectTrigger className="h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                          <SelectValue placeholder="Seleccionar sector" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Tecnología">💻 Tecnología</SelectItem>
                          <SelectItem value="Finanzas">💰 Finanzas</SelectItem>
                          <SelectItem value="Salud">🏥 Salud</SelectItem>
                          <SelectItem value="Retail">🛍️ Retail</SelectItem>
                          <SelectItem value="Educación">📚 Educación</SelectItem>
                          <SelectItem value="Manufactura">🏭 Manufactura</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button type="submit" disabled={loading} className="flex-1 bg-blue-600 hover:bg-blue-700 h-12 font-semibold">
                      {loading ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Analizando...
                        </>
                      ) : (
                        <>
                          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                          </svg>
                          Predecir Conversión
                        </>
                      )}
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowPredictionForm(false)}
                      className="flex-1 h-12 font-semibold border-gray-300 hover:bg-gray-50"
                    >
                      Cancelar
                    </Button>
                  </div>
                </form>
              )}
            </CardContent>
          </Card>

          {/* Resultados de Predicción */}
          <Card className="shadow-lg border-0">
            <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white">
              <CardTitle className="text-xl font-semibold flex items-center">
                <div className="w-3 h-3 bg-white rounded-full mr-3"></div>
                Resultados del Análisis
              </CardTitle>
              <CardDescription className="text-green-100">
                Predicción basada en Machine Learning avanzado
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              {predictionResult ? (
                <div className="space-y-6">
                  {/* Probabilidad Principal */}
                  <div className="text-center py-8 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
                    <div className="text-6xl font-bold text-blue-600 mb-3">
                      {(predictionResult.probabilidadConversion * 100).toFixed(1)}%
                    </div>
                    <div className="text-xl text-gray-700 mb-5 font-medium">
                      Probabilidad de Conversión
                    </div>
                    <Progress value={predictionResult.probabilidadConversion * 100} className="max-w-sm mx-auto mb-5 h-4" />
                    <Badge 
                      className={`${predictionResult.clasificacion === 'Alta' ? 'bg-green-100 text-green-800 border-green-300' : 
                                  predictionResult.clasificacion === 'Media' ? 'bg-amber-100 text-amber-800 border-amber-300' : 
                                  'bg-gray-100 text-gray-800 border-gray-300'} text-base px-6 py-3 font-semibold`}
                    >
                      {predictionResult.clasificacion === 'Alta' && '🟢'} 
                      {predictionResult.clasificacion === 'Media' && '🟡'} 
                      {predictionResult.clasificacion === 'Baja' && '🔴'} 
                      {' ' + predictionResult.clasificacion + ' Probabilidad'}
                    </Badge>
                  </div>

                  <Separator />

                  {/* Recomendación */}
                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-5 border border-blue-200">
                    <h4 className="font-bold text-gray-900 mb-3 flex items-center text-lg">
                      <div className="w-3 h-3 bg-blue-600 rounded-full mr-3"></div>
                      Recomendación Estratégica
                    </h4>
                    <p className="text-gray-700 leading-relaxed font-medium">
                      {predictionResult.recomendacion}
                    </p>
                  </div>

                  <Separator />

                  {/* Factores de Influencia */}
                  <div>
                    <h4 className="font-bold text-gray-900 mb-5 flex items-center text-lg">
                      <div className="w-3 h-3 bg-purple-600 rounded-full mr-3"></div>
                      Factores de Influencia
                    </h4>
                    <div className="space-y-4">
                      {predictionResult.factoresInfluencia.map((factor, index) => (
                        <div key={index} className="bg-gray-50 rounded-lg p-4 border-l-4 border-blue-500">
                          <div className="flex justify-between items-center mb-3">
                            <span className="font-semibold text-gray-900">{factor.factor}</span>
                            <span className="text-lg font-bold text-blue-600">{factor.peso.toFixed(0)}%</span>
                          </div>
                          <Progress value={factor.peso} className="mb-3 h-3" />
                          <p className="text-sm text-gray-600 italic font-medium">{factor.descripcion}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button 
                    onClick={() => {
                      setPredictionResult(null);
                      setFormData({
                        fuenteOrigen: '',
                        tiempoEnSitioMin: '',
                        visitasTotales: '',
                        diasUltimoContacto: '',
                        cargo: '',
                        sector: ''
                      });
                    }}
                    variant="outline"
                    className="w-full h-12 font-semibold border-gray-300 hover:bg-gray-50"
                  >
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                    Nueva Evaluación
                  </Button>
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Sin resultados aún</h3>
                  <p className="text-gray-600 max-w-sm mx-auto">
                    Completa el formulario de evaluación para ver el análisis detallado de predicción con nuestra inteligencia artificial
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-l-4 border-l-blue-600">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Leads</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats?.totalLeads || 0}</div>
              <p className="text-xs text-gray-500 mt-1">Prospectos registrados</p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-600">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Convertidos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats?.convertidos || 0}</div>
              <p className="text-xs text-gray-500 mt-1">Clientes potenciales</p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-amber-600">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Tasa de Conversión</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats?.tasaConversion.toFixed(1) || 0}%</div>
              <Progress value={stats?.tasaConversion || 0} className="mt-2 h-2" />
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-600">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Precisión del Modelo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">82.3%</div>
              <p className="text-xs text-gray-500 mt-1">Machine Learning</p>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos y Predicción */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Gráfico de Barras */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900">Distribución por Fuente de Origen</CardTitle>
              <CardDescription>Análisis de leads según canal de adquisición</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={stats?.distribucionFuentes || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="fuente" tick={{ fill: '#666' }} />
                  <YAxis tick={{ fill: '#666' }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e0e0e0', borderRadius: '8px' }}
                  />
                  <Bar dataKey="count" fill="#0056B3" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Gráfico Circular */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900">Participación por Canal</CardTitle>
              <CardDescription>Distribución porcentual</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={stats?.distribucionFuentes || []}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="count"
                  >
                    {(stats?.distribucionFuentes || []).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-4 space-y-2">
                {(stats?.distribucionFuentes || []).map((item, index) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full mr-2`} style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                      <span className="text-gray-600">{item.fuente}</span>
                    </div>
                    <span className="font-medium text-gray-900">{item.percentage.toFixed(1)}%</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-6 h-6 bg-blue-600 rounded mr-2"></div>
                <span className="text-lg font-semibold">LeadPredict AI</span>
              </div>
              <p className="text-gray-400 text-sm">Sistema inteligente de predicción de leads con Machine Learning</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Características</h4>
              <ul className="text-gray-400 text-sm space-y-2">
                <li>• Predicción en tiempo real</li>
                <li>• Análisis multivariable</li>
                <li>• Dashboard interactivo</li>
                <li>• Reportes automáticos</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Tecnología</h4>
              <ul className="text-gray-400 text-sm space-y-2">
                <li>• Machine Learning</li>
                <li>• Inteligencia Artificial</li>
                <li>• Análisis Predictivo</li>
                <li>• Big Data</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Soporte</h4>
              <ul className="text-gray-400 text-sm space-y-2">
                <li>• Documentación técnica</li>
                <li>• Guías de uso</li>
                <li>• API Reference</li>
                <li>• Contacto</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2024 LeadPredict AI. Todos los derechos reservados. | Desarrollado con Next.js y Machine Learning</p>
          </div>
        </div>
      </footer>
    </div>
  );
}